use VRML;

print VRML->new->browser("Cosmo Player 2.0")->background("black", "starbak.gif")->cube(2,"orange")->as_string;
